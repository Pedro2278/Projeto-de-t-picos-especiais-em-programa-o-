class Aluno < ApplicationRecord
end
