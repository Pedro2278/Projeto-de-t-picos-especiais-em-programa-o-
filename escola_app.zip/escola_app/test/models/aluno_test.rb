require "test_helper"

class AlunoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
